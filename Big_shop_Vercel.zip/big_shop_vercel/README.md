# Big_shop — prêt pour Vercel

## Contenu
- `index.html` : site Big_shop avec le chat qui appelle `/api/chat`.
- `api/chat.js` : fonction serveur Vercel qui appelle l'API OpenAI Responses.
- `package.json` : dépendance officielle `openai`.

## Déploiement
1. Décompressez ce dossier sur votre ordinateur.
2. Importez le dossier/projet dans un dépôt GitHub privé ou public selon votre préférence.
3. Dans Vercel, choisissez **Add New → Project**, puis importez le dépôt.
4. Gardez les paramètres de build par défaut (site HTML statique, fonction dans `api/`).
5. Dans **Project → Settings → Environment Variables**, ajoutez :
   - `OPENAI_API_KEY` = votre clé API OpenAI secrète.
   - `OPENAI_MODEL` = `gpt-6-astra` (facultatif, valeur par défaut déjà prévue).
6. Activez au minimum l'environnement **Production** (et Preview si souhaité), enregistrez, puis redéployez.
7. Testez le site publié : ouvrez le chat et demandez « Quels sont vos prix ? ».

## Sécurité
- Ne mettez jamais `OPENAI_API_KEY` dans `index.html`, dans un nom `NEXT_PUBLIC_...`, ni dans GitHub.
- Ne partagez pas votre clé dans une conversation ou une capture d'écran.
- L'utilisation de l'API est facturée séparément de l'abonnement ChatGPT.
- Avant une diffusion publique importante, ajoutez une protection anti-abus (limitation de débit / CAPTCHA) à la route `/api/chat`.

## Développement local
Installez Node.js 20+, puis dans ce dossier :

```bash
npm install
npx vercel dev
```

Configurez `OPENAI_API_KEY` dans les variables d'environnement locales ou dans Vercel CLI. Ne commitez jamais `.env.local`.
